class AppImages {
  static const String logo = "assets/images/amco.png";
  static const String user = "assets/images/user.png";
  static const String Announcement = "assets/images/Announcement.png";
  static const String banner = "assets/images/banner.png";
}
