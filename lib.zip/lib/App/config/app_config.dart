class AppConfig {
  static late String apiBaseUrl;

  static void initialize() {
    apiBaseUrl = "https://yourapi.com/api/";


  }
}
