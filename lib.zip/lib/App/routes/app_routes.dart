class AppRoutes {
  static const SPLASH = '/';
  static const LOGIN = '/login';
  static const DASHBOARD = '/DashboardView';
  static const UnionUpdatePage = '/UnionUpdatePage';
  static const UnionUpdateDetailPage = '/UnionUpdateDetailPage';
  static const ProfilePage = '/ProfilePage';
  static const EditProfilePage = '/EditProfilePage';
}
